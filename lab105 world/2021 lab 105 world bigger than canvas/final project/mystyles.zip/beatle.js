

//  Mover constructor function +++++++++++++++++++++++++++++

function Beatle(){
	this.type = "BEATLE"
	this.clr = "rgba(" + Math.random()*15 + "," + Math.random()*15 + "," + Math.random()*255 + ",255)";
	this.loc = new JSVector(700,750);
	this.radius = 30;
	this.velocity = new JSVector(0.4,0.04);
	this.acceleration = new JSVector(0.00,0.00);
	this.particles = [];
	//this.crackle = new JSVector(0.0000001,0.00000001);
	//this.pop = new JSVector(-0.0000001,-0.00000001);
	
}

Beatle.prototype.run = function(){
	//this.movement = new JSVector.subGetNew(this.mover,this.loc);
	//this.movement.normalize();
	//this.movement.setMagnitude(0.4);
	//if(Math.random() < 0.2) {
		
	let list = game.objects;
	for(var i = 0; i < list.length; i++) {
		//console.log("a");
		
		
		
		if(list[i].type == "FLOCK") {
			
		
			for(var b = 0; b < list[i].automobiles.length; b++) {
				//console.log("ga");
				let d = Math.sqrt((this.loc.x-list[i].automobiles[b].location.x)*(this.loc.x-list[i].automobiles[b].location.x) + (this.loc.y-list[i].automobiles[b].location.y)*(this.loc.y-list[i].automobiles[b].location.y));
				//console.log(d);
				if(d < 250) {
					
					
				}
					
				
			}
		}
	}
	
	
	this.particles.push(new Flame(this.loc.x,this.loc.y,this.velocity.x*16,this.velocity.y*16,40));
	for(var i = 0; i < this.particles.length; i++) {
		if(this.particles[i].lifeTime < 0) {
			this.particles.splice(i);
		}
		
	}
	for(var i = 0; i < this.particles.length; i++) {
		
		this.particles[i].run();
		
	}
	this.loc.add(this.velocity);
	this.velocity.add(this.acceleration);
	//this.acceleration.add(this.jerk);
	//this.jerk.add(this.crackle);
	//this.crackle.add(this.pop);
	//}
	
	//this.render();

	
	
	this.checkEdges();
	
	this.render();
}

Beatle.prototype.render = function(){
    let ctx = game.ctx;
	//ctx.fillRect(25, 255, 100, 100);
	
	ctx.strokeStyle = this.clr;
	ctx.fillStyle = this.clr;
	ctx.lineWidth = 2;
	//
	if(Math.random() < 0.01) {
		this.acceleration.x = Math.random()*0.01-0.005;
		this.acceleration.y = Math.random()*0.01-0.005;	
	}
	
	ctx.save();
	ctx.beginPath();
	//ctx.translate(this.loc.x,this.loc.y);
	
	ctx.lineWidth = 20;
	ctx.arc(this.loc.x, this.loc.y, this.radius, Math.PI *2, 0, false);
	ctx.stroke();
	ctx.beginPath();
	ctx.translate(this.loc.x,this.loc.y);
	ctx.rotate(this.velocity.getDirection());
	ctx.lineTo(0,0);
	ctx.arc(100, -30, this.radius/4, Math.PI *2, 0, false);
	ctx.stroke();
	ctx.beginPath();
	//ctx.lineTo(0,0);
	ctx.arc(100, 30, this.radius/4, Math.PI *2, 0, false);
	ctx.lineTo(0,0);
	//ctx.lineTo(50, -100)
	
	//ctx.fill();
	//ctx.lineTo(0,0);
	ctx.stroke();
	ctx.restore();
	
	//console.log('head at' + this.loc.x + ' ' + this.loc.y);
	//console.log('segment at' + this.segments[0].x + ' ' + this.segments[0].y);
	//ctx.fill();
	//ctx.lineCap = "round";


	//ctx.stroke();

	//
 }

Beatle.prototype.checkEdges = function(){
    let canvas = game.canvas;
    if(this.loc.x > canvas.width)  this.velocity.x = this.velocity.x * -1; // wrap around from right to left
    if(this.loc.x < 0)  this.velocity.x = this.velocity.x * -1; // wrap around from left to right
    if(this.loc.y > canvas.height)  this.velocity.y = this.velocity.y * -1; // wrap around from bottom to top
    if(this.loc.y < 0)  this.velocity.y = this.velocity.y * -1; // wrap around from top to bottom
  }
